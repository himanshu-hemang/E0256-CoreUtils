use std::env;
use std::io::Write;
use std::fs::File;
use std::path::Path;

static TEMPLATE: &'static str = "\
extern crate uu_@UTIL_CRATE@;

use std::io::Write;
use uu_@UTIL_CRATE@::uumain;

fn main() {
    
    let code = uumain(std::env::args().collect());
     std::io::stdout().flush().expect(\"could not flush stdout\");
    std::process::exit(code);
}
";

pub fn main() {
    let out_dir = env::var("OUT_DIR").unwrap();
    let pkgname = env::var("CARGO_PKG_NAME").unwrap();
	
    let main = TEMPLATE.replace("@UTIL_CRATE@", &pkgname);
    let mut file = File::create(&Path::new(&out_dir).join("main.rs")).unwrap();
	
	
	
    write!(file, "{}", main).unwrap();
}
